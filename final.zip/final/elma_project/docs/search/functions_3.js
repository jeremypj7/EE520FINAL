var searchData=
[
  ['offstate',['OffState',['../classstopwatch_1_1OffState.html#a421aa693834d809dfb2e39ec3bd3cc2e',1,'stopwatch::OffState']]],
  ['onstate',['OnState',['../classstopwatch_1_1OnState.html#a247e867c94f178ca06be04de762dbe52',1,'stopwatch::OnState']]]
];
