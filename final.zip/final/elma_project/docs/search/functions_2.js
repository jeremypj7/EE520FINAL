var searchData=
[
  ['lap',['lap',['../classstopwatch_1_1StopWatch.html#a8e25f50201831578ad0b588a4ce16504',1,'stopwatch::StopWatch']]],
  ['laps',['laps',['../classstopwatch_1_1StopWatch.html#a8b335f9667cd518297ca3be4e57c4972',1,'stopwatch::StopWatch']]]
];
