var searchData=
[
  ['update',['update',['../classstopwatch_1_1UserInterface.html#a7c9acd9ad089bbd6d0ca371a14cd82fa',1,'stopwatch::UserInterface']]],
  ['userinterface',['UserInterface',['../classstopwatch_1_1UserInterface.html#a3567885d49505d1f4c0c6fff3bf3d386',1,'stopwatch::UserInterface']]]
];
