var searchData=
[
  ['reset',['reset',['../classstopwatch_1_1StopWatch.html#a1c0dcc57c615559f24bc9f8759271a9d',1,'stopwatch::StopWatch']]],
  ['rover',['Rover',['../classRover.html',1,'']]],
  ['roverstate',['RoverState',['../classRoverState.html',1,'']]]
];
